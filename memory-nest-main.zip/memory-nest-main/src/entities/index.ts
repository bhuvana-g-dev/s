/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: dailygreetingmessages
 * Interface for DailyGreetingMessages
 */
export interface DailyGreetingMessages {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  messageText?: string;
  /** @wixFieldType text */
  author?: string;
  /** @wixFieldType text */
  category?: string;
  /** @wixFieldType text */
  mood?: string;
  /** @wixFieldType boolean */
  isActive?: boolean;
}


/**
 * Collection ID: loadingscreenmessages
 * Interface for LoadingScreenMessages
 */
export interface LoadingScreenMessages {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  messageText?: string;
  /** @wixFieldType number */
  displayOrder?: number;
  /** @wixFieldType boolean */
  isActive?: boolean;
  /** @wixFieldType text */
  category?: string;
  /** @wixFieldType number */
  displayDurationSeconds?: number;
}


/**
 * Collection ID: memoryjarmessages
 * Interface for MemoryJarMessages
 */
export interface MemoryJarMessages {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  messageText?: string;
  /** @wixFieldType text */
  sentiment?: string;
  /** @wixFieldType text */
  author?: string;
  /** @wixFieldType boolean */
  isActive?: boolean;
  /** @wixFieldType number */
  displayPriority?: number;
}


/**
 * Collection ID: specialoccasionmessages
 * Interface for SpecialOccasionMessages
 */
export interface SpecialOccasionMessages {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  occasionName?: string;
  /** @wixFieldType date */
  targetDate?: Date | string;
  /** @wixFieldType text */
  messageContent?: string;
  /** @wixFieldType boolean */
  isActive?: boolean;
  /** @wixFieldType number */
  displayOrder?: number;
  /** @wixFieldType url */
  celebrationImageUrl?: string;
}
