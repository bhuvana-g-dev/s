import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sunrise, Sun, Sunset, Moon, Cake, Sparkles } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { DailyGreetingMessages, SpecialOccasionMessages } from '@/entities';

export default function GreetingCard() {
  const [greeting, setGreeting] = useState('');
  const [icon, setIcon] = useState<React.ReactNode>(null);
  const [dailyMessage, setDailyMessage] = useState('');
  const [isBirthday, setIsBirthday] = useState(false);
  const [birthdayMessage, setBirthdayMessage] = useState('');

  useEffect(() => {
    checkDate();
    loadDailyMessage();
  }, []);

  const checkDate = async () => {
    const now = new Date();
    const month = now.getMonth() + 1; // 0-indexed
    const day = now.getDate();

    // Check if it's July 26
    if (month === 7 && day === 26) {
      setIsBirthday(true);
      await loadBirthdayMessage();
    } else {
      setIsBirthday(false);
      setGreetingByTime();
    }
  };

  const setGreetingByTime = () => {
    const hour = new Date().getHours();
    
    if (hour >= 5 && hour < 12) {
      setGreeting('Good Morning');
      setIcon(<Sunrise className="w-12 h-12 text-primary" />);
    } else if (hour >= 12 && hour < 17) {
      setGreeting('Good Afternoon');
      setIcon(<Sun className="w-12 h-12 text-primary" />);
    } else if (hour >= 17 && hour < 21) {
      setGreeting('Good Evening');
      setIcon(<Sunset className="w-12 h-12 text-primary" />);
    } else {
      setGreeting('Good Night');
      setIcon(<Moon className="w-12 h-12 text-primary" />);
    }
  };

  const loadDailyMessage = async () => {
    try {
      const result = await BaseCrudService.getAll<DailyGreetingMessages>('dailygreetingmessages');
      const activeMessages = result.items.filter(msg => msg.isActive);
      
      if (activeMessages.length > 0) {
        // Get a consistent random message based on the day
        const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
        const messageIndex = dayOfYear % activeMessages.length;
        setDailyMessage(activeMessages[messageIndex].messageText || '');
      }
    } catch (error) {
      console.error('Error loading daily message:', error);
    }
  };

  const loadBirthdayMessage = async () => {
    try {
      const result = await BaseCrudService.getAll<SpecialOccasionMessages>('specialoccasionmessages');
      const birthdayMsg = result.items.find(msg => 
        msg.isActive && msg.occasionName?.toLowerCase().includes('birthday')
      );
      
      if (birthdayMsg) {
        setBirthdayMessage(birthdayMsg.messageContent || 'Happy Birthday! ❤️');
      }
    } catch (error) {
      console.error('Error loading birthday message:', error);
    }
  };

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="flex items-center justify-center relative">
      {/* Birthday Confetti */}
      {isBirthday && (
        <>
          {[...Array(30)].map((_, i) => (
            <motion.div
              key={`confetti-${i}`}
              className="absolute w-3 h-3 rounded-full"
              style={{
                backgroundColor: ['#FFB6C1', '#E6E6FA', '#FFD1DC', '#D8BFD8'][i % 4],
                left: `${Math.random() * 100}%`,
                top: '-10%'
              }}
              animate={{
                y: [0, window.innerHeight],
                x: [0, (Math.random() - 0.5) * 200],
                rotate: [0, 360 * (Math.random() > 0.5 ? 1 : -1)],
                opacity: [1, 0]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: i * 0.1,
                ease: 'easeOut'
              }}
            />
          ))}
        </>
      )}

      {/* Glass Card */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0, y: 50 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ 
          duration: 0.8, 
          delay: 0.3,
          type: 'spring',
          stiffness: 100
        }}
        className="relative max-w-2xl w-full mx-auto"
      >
        <motion.div
          animate={{
            boxShadow: [
              '0 8px 32px rgba(255, 182, 193, 0.2)',
              '0 8px 40px rgba(255, 182, 193, 0.4)',
              '0 8px 32px rgba(255, 182, 193, 0.2)',
            ]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="backdrop-blur-lg bg-white/20 border border-white/40 rounded-3xl p-12 shadow-2xl"
        >
          {/* Date */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center mb-6"
          >
            <p className="font-paragraph text-lg text-foreground/80">
              {currentDate}
            </p>
          </motion.div>

          {/* Icon and Greeting */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7, type: 'spring', stiffness: 200 }}
            className="flex flex-col items-center gap-4 mb-8"
          >
            {isBirthday ? (
              <>
                <motion.div
                  animate={{
                    rotate: [0, -10, 10, -10, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut'
                  }}
                >
                  <Cake className="w-16 h-16 text-primary" />
                </motion.div>
                <h1 className="font-heading text-5xl md:text-6xl text-foreground font-bold text-center">
                  Happy Birthday ❤️
                </h1>
              </>
            ) : (
              <>
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: 'easeInOut'
                  }}
                >
                  {icon}
                </motion.div>
                <h1 className="font-heading text-5xl md:text-6xl text-foreground font-bold text-center">
                  {greeting}
                </h1>
              </>
            )}
          </motion.div>

          {/* Daily Message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="text-center"
          >
            <div className="relative inline-block">
              <motion.div
                animate={{
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: 'easeInOut'
                }}
                className="absolute -top-2 -right-2"
              >
                <Sparkles className="w-5 h-5 text-primary" />
              </motion.div>
              <p className="font-paragraph text-xl md:text-2xl text-foreground leading-relaxed px-4">
                {isBirthday ? birthdayMessage : dailyMessage}
              </p>
            </div>
          </motion.div>

          {/* Birthday Sparkles */}
          {isBirthday && (
            <motion.div
              className="flex justify-center gap-4 mt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
            >
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  animate={{
                    y: [0, -20, 0],
                    opacity: [0.5, 1, 0.5]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: i * 0.3,
                    ease: 'easeInOut'
                  }}
                >
                  <Sparkles className="w-6 h-6 text-primary" />
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}
