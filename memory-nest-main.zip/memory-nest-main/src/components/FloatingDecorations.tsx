import { motion } from 'framer-motion';
import { Heart, Sparkles } from 'lucide-react';

export default function FloatingDecorations() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Floating Hearts */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={`float-heart-${i}`}
          className="absolute text-primary opacity-20"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`
          }}
          animate={{
            y: [0, -50, 0],
            x: [0, Math.random() * 30 - 15, 0],
            rotate: [0, 10, -10, 0],
            opacity: [0.1, 0.3, 0.1]
          }}
          transition={{
            duration: 8 + Math.random() * 4,
            repeat: Infinity,
            delay: i * 1.5,
            ease: 'easeInOut'
          }}
        >
          <Heart className="w-8 h-8 fill-current" />
        </motion.div>
      ))}

      {/* Floating Sparkles */}
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={`float-sparkle-${i}`}
          className="absolute text-accent-lavender opacity-25"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`
          }}
          animate={{
            y: [0, -40, 0],
            x: [0, Math.random() * 40 - 20, 0],
            rotate: [0, 180, 360],
            scale: [0.5, 1, 0.5],
            opacity: [0.1, 0.4, 0.1]
          }}
          transition={{
            duration: 6 + Math.random() * 3,
            repeat: Infinity,
            delay: i * 0.8,
            ease: 'easeInOut'
          }}
        >
          <Sparkles className="w-6 h-6" />
        </motion.div>
      ))}

      {/* Floating Petals */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`petal-${i}`}
          className="absolute rounded-full bg-accent-pink opacity-20"
          style={{
            width: `${8 + Math.random() * 8}px`,
            height: `${12 + Math.random() * 12}px`,
            left: `${Math.random() * 100}%`,
            top: `-5%`
          }}
          animate={{
            y: [0, window.innerHeight + 100],
            x: [0, (Math.random() - 0.5) * 200],
            rotate: [0, 360 * (Math.random() > 0.5 ? 1 : -1)],
            opacity: [0.2, 0.4, 0.2, 0]
          }}
          transition={{
            duration: 12 + Math.random() * 8,
            repeat: Infinity,
            delay: i * 2,
            ease: 'linear'
          }}
        />
      ))}

      {/* Gentle Cursor Glow Effect */}
      <motion.div
        className="absolute w-96 h-96 rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(255, 182, 193, 0.15) 0%, transparent 70%)',
          filter: 'blur(40px)'
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
    </div>
  );
}
