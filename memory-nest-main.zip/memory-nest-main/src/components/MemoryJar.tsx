import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { MemoryJarMessages } from '@/entities';

export default function MemoryJar() {
  const [isNoteOpen, setIsNoteOpen] = useState(false);
  const [dailyNote, setDailyNote] = useState('');

  useEffect(() => {
    loadDailyNote();
    // Automatically open the note after a delay
    const timer = setTimeout(() => {
      setIsNoteOpen(true);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const loadDailyNote = async () => {
    try {
      const result = await BaseCrudService.getAll<MemoryJarMessages>('memoryjarmessages');
      const activeMessages = result.items
        .filter(msg => msg.isActive)
        .sort((a, b) => (b.displayPriority || 0) - (a.displayPriority || 0));
      
      if (activeMessages.length > 0) {
        // Get a consistent random message based on the day
        const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
        const messageIndex = dayOfYear % activeMessages.length;
        setDailyNote(activeMessages[messageIndex].messageText || '');
      }
    } catch (error) {
      console.error('Error loading memory jar message:', error);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center gap-12 px-4">
      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center"
      >
        <h2 className="font-heading text-4xl md:text-5xl text-foreground font-bold mb-4">
          Memory Jar
        </h2>
        <p className="font-paragraph text-lg text-foreground/70">
          A little note for you today
        </p>
      </motion.div>

      {/* Jar Container */}
      <div className="relative w-full max-w-md">
        {/* Glass Jar */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          {/* Jar Body */}
          <div className="relative backdrop-blur-lg bg-white/30 border-4 border-white/50 rounded-3xl rounded-t-lg h-96 shadow-2xl overflow-hidden">
            {/* Jar Lid */}
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-32 h-8 backdrop-blur-md bg-white/40 border-2 border-white/60 rounded-t-xl shadow-lg" />
            
            {/* Sparkles inside jar */}
            {!isNoteOpen && (
              <>
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={`jar-sparkle-${i}`}
                    className="absolute text-primary opacity-40"
                    style={{
                      left: `${20 + Math.random() * 60}%`,
                      top: `${30 + Math.random() * 50}%`
                    }}
                    animate={{
                      scale: [0.5, 1, 0.5],
                      opacity: [0.2, 0.6, 0.2],
                      rotate: [0, 180, 360]
                    }}
                    transition={{
                      duration: 3 + Math.random() * 2,
                      repeat: Infinity,
                      delay: i * 0.3,
                      ease: 'easeInOut'
                    }}
                  >
                    <Sparkles className="w-4 h-4" />
                  </motion.div>
                ))}
              </>
            )}

            {/* Folded Notes inside jar */}
            {!isNoteOpen && (
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-wrap justify-center gap-2 w-full px-8">
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={`note-${i}`}
                    className="w-12 h-12 bg-gradient-to-br from-accent-pink to-accent-lavender rounded-lg shadow-md"
                    animate={{
                      y: [0, -5, 0],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{
                      duration: 2 + Math.random(),
                      repeat: Infinity,
                      delay: i * 0.2,
                      ease: 'easeInOut'
                    }}
                  />
                ))}
              </div>
            )}

            {/* Floating Note Animation */}
            <AnimatePresence>
              {isNoteOpen && (
                <motion.div
                  initial={{ 
                    y: 300,
                    x: 0,
                    scale: 0.3,
                    rotate: 0
                  }}
                  animate={{ 
                    y: -100,
                    x: 0,
                    scale: 1,
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{
                    duration: 2,
                    ease: 'easeOut'
                  }}
                  className="absolute bottom-0 left-1/2 transform -translate-x-1/2"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-accent-pink to-accent-lavender rounded-lg shadow-lg" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Unfolded Note */}
        <AnimatePresence>
          {isNoteOpen && (
            <motion.div
              initial={{ 
                scale: 0.3,
                opacity: 0,
                y: -50
              }}
              animate={{ 
                scale: 1,
                opacity: 1,
                y: -180
              }}
              transition={{
                duration: 1,
                delay: 2,
                type: 'spring',
                stiffness: 100
              }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 w-full max-w-sm"
            >
              <motion.div
                animate={{
                  rotate: [-2, 2, -2],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut'
                }}
                className="backdrop-blur-md bg-gradient-to-br from-accent-pink/80 to-accent-lavender/80 border-2 border-white/50 rounded-2xl p-8 shadow-2xl"
              >
                {/* Decorative corners */}
                <div className="absolute top-2 right-2">
                  <Sparkles className="w-5 h-5 text-primary opacity-60" />
                </div>
                <div className="absolute bottom-2 left-2">
                  <Sparkles className="w-5 h-5 text-primary opacity-60" />
                </div>

                <p className="font-paragraph text-lg md:text-xl text-foreground text-center leading-relaxed">
                  {dailyNote}
                </p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom spacing for unfolded note */}
      {isNoteOpen && <div className="h-32" />}
    </div>
  );
}
