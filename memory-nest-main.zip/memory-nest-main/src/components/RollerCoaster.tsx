import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export default function RollerCoaster() {
  const navigate = useNavigate();
  const [isRiding, setIsRiding] = useState(false);

  const handleStartRide = async () => {
    setIsRiding(true);

    // Animate the ride
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Navigate to the next page
    navigate('/our-journey');
  };

  return (
    <div className="flex flex-col items-center justify-center gap-6 md:gap-8 w-full h-full px-4">
      {/* Amusement park scene */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="relative w-full max-w-sm h-64 md:h-80 bg-gradient-to-b from-sky-200 to-sky-100 rounded-2xl overflow-hidden shadow-xl"
      >
        {/* Clouds */}
        <motion.div
          animate={{ x: [0, 20, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-8 left-4 w-16 h-8 bg-white rounded-full opacity-70"
        />
        <motion.div
          animate={{ x: [0, -15, 0] }}
          transition={{ duration: 10, repeat: Infinity, delay: 1 }}
          className="absolute top-20 right-8 w-20 h-10 bg-white rounded-full opacity-60"
        />

        {/* Trees */}
        <div className="absolute bottom-0 left-4 flex gap-2">
          {[1, 2].map((i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="w-8 h-16 bg-amber-700 rounded-sm" />
              <div className="w-12 h-12 bg-green-500 rounded-full" />
            </div>
          ))}
        </div>

        {/* Flowers */}
        <div className="absolute bottom-8 right-6 flex gap-3">
          {['🌸', '🌼', '🌺'].map((flower, i) => (
            <motion.div
              key={i}
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 3, repeat: Infinity, delay: i * 0.3 }}
              className="text-2xl"
            >
              {flower}
            </motion.div>
          ))}
        </div>

        {/* Roller coaster track */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 400 300"
          preserveAspectRatio="none"
        >
          {/* Track */}
          <path
            d="M 50 200 Q 100 100 150 150 T 250 80 T 350 200"
            stroke="#8B4513"
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
          />
          {/* Support beams */}
          <line x1="100" y1="150" x2="100" y2="250" stroke="#666" strokeWidth="3" />
          <line x1="200" y1="100" x2="200" y2="250" stroke="#666" strokeWidth="3" />
          <line x1="300" y1="140" x2="300" y2="250" stroke="#666" strokeWidth="3" />
        </svg>

        {/* Cart with animation */}
        <motion.div
          animate={
            isRiding
              ? {
                  x: [50, 150, 250, 350],
                  y: [200, 100, 150, 80],
                }
              : {
                  y: [0, -4, 0],
                }
          }
          transition={
            isRiding
              ? { duration: 2, ease: 'easeInOut' }
              : { duration: 3, repeat: Infinity }
          }
          className="absolute w-12 h-8 bg-gradient-to-r from-red-400 to-red-500 rounded-lg shadow-lg flex items-center justify-center text-lg"
          style={{ left: '50px', top: '200px' }}
        >
          <span className="text-sm">👧👧</span>
        </motion.div>
      </motion.div>

      {/* Text content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="text-center"
      >
        <p className="text-lg md:text-xl font-paragraph text-secondary-foreground mb-2">
          Ready to relive our memories?
        </p>
        <p className="text-sm font-paragraph text-secondary-foreground opacity-75 mb-6">
          Every moment we shared is a treasure
        </p>
      </motion.div>

      {/* Start button */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={handleStartRide}
          disabled={isRiding}
          className="bg-gradient-to-r from-primary to-accent-pink text-primary-foreground font-heading text-base md:text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
        >
          {isRiding ? 'Starting the ride...' : 'Start the Ride 🎢'}
        </Button>
      </motion.div>

      {/* Transition animation overlay */}
      {isRiding && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.5 }}
          className="fixed inset-0 bg-gradient-to-r from-primary via-accent-lavender to-accent-pink pointer-events-none"
        />
      )}
    </div>
  );
}
