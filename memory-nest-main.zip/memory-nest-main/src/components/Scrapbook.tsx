import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Image } from '@/components/ui/image';

// Placeholder data - will be replaced with real photos later
const scrapbookPages = [
  {
    id: 1,
    photos: [
      {
        id: 'photo-1',
        url: 'https://static.wixstatic.com/media/6c5646_f624b038d34d42b99f739dce653aed71~mv2.png?originWidth=128&originHeight=192',
        caption: 'Our first adventure',
        size: 'large',
      },
    ],
  },
  {
    id: 2,
    photos: [
      {
        id: 'photo-2',
        url: 'https://static.wixstatic.com/media/6c5646_a8fb9d573f92427c8e6f104dc240e121~mv2.png?originWidth=128&originHeight=192',
        caption: 'Laughing together',
        size: 'small',
      },
      {
        id: 'photo-3',
        url: 'https://static.wixstatic.com/media/6c5646_f52dc2c6ea394c21842d2b09b7eb37c3~mv2.png?originWidth=128&originHeight=192',
        caption: 'Sunny days',
        size: 'small',
      },
    ],
  },
  {
    id: 3,
    photos: [
      {
        id: 'photo-4',
        url: 'https://static.wixstatic.com/media/6c5646_61b31d43e2dd4494be2ea34ffd03506d~mv2.png?originWidth=128&originHeight=192',
        caption: 'Making memories',
        size: 'large',
      },
    ],
  },
];

const stickers = ['🌸', '💕', '⭐', '🦋', '🌼', '🎀'];

export default function Scrapbook() {
  const [currentPage, setCurrentPage] = useState(0);
  const [isFlipping, setIsFlipping] = useState(false);

  const handleNextPage = () => {
    if (currentPage < scrapbookPages.length - 1 && !isFlipping) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(currentPage + 1);
        setIsFlipping(false);
      }, 600);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 0 && !isFlipping) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(currentPage - 1);
        setIsFlipping(false);
      }, 600);
    }
  };

  const currentPageData = scrapbookPages[currentPage];

  return (
    <div className="flex flex-col items-center gap-6 w-full">
      {/* Title */}
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-2xl md:text-3xl font-heading text-center text-primary"
      >
        A Book Filled With Your Smiles ❤️
      </motion.h2>

      {/* Scrapbook */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="relative w-full max-w-md aspect-[3/4] bg-gradient-to-br from-amber-900 to-amber-800 rounded-lg shadow-2xl p-4 md:p-6 border-8 border-amber-950"
        style={{
          backgroundImage: `linear-gradient(135deg, #8B6914 0%, #A0826D 50%, #8B6914 100%)`,
        }}
      >
        {/* Spiral binding effect */}
        <div className="absolute left-6 top-0 bottom-0 w-8 flex flex-col gap-2 items-center justify-center">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="w-6 h-2 bg-yellow-600 rounded-full shadow-md"
              style={{
                boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3)',
              }}
            />
          ))}
        </div>

        {/* Gold corners */}
        {[
          'top-2 left-2',
          'top-2 right-2',
          'bottom-2 left-2',
          'bottom-2 right-2',
        ].map((pos, i) => (
          <div
            key={i}
            className={`absolute w-6 h-6 bg-yellow-500 rounded-sm ${pos}`}
            style={{
              boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
            }}
          />
        ))}

        {/* Paper pages */}
        <div className="relative w-full h-full bg-gradient-to-b from-amber-50 to-amber-100 rounded-sm p-4 md:p-6 overflow-hidden">
          {/* Page texture */}
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' /%3E%3C/filter%3E%3Crect width='100' height='100' filter='url(%23noise)' /%3E%3C/svg%3E")`,
            }}
          />

          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ rotateY: 90, opacity: 0 }}
              animate={{ rotateY: 0, opacity: 1 }}
              exit={{ rotateY: -90, opacity: 0 }}
              transition={{ duration: 0.6, ease: 'easeInOut' }}
              className="relative w-full h-full flex flex-col items-center justify-center"
              style={{
                perspective: '1000px',
              }}
            >
              {/* Photos layout */}
              <div className="w-full h-full flex flex-col gap-3 md:gap-4 items-center justify-center relative z-10">
                {currentPageData.photos.map((photo, idx) => (
                  <motion.div
                    key={photo.id}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2 + idx * 0.1 }}
                    className={`relative bg-white rounded-sm shadow-lg border-4 border-white ${
                      photo.size === 'large'
                        ? 'w-32 h-40 md:w-40 md:h-48'
                        : 'w-24 h-28 md:w-28 md:h-32'
                    }`}
                    style={{
                      boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
                      transform: `rotate(${idx % 2 === 0 ? -2 : 2}deg)`,
                    }}
                  >
                    <Image src={photo.url} alt={photo.caption} className="w-full h-full object-cover rounded-sm" />
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.4 }}
                      className="absolute -bottom-8 left-0 right-0 text-center text-xs md:text-sm font-paragraph text-secondary-foreground italic"
                    >
                      {photo.caption}
                    </motion.p>
                  </motion.div>
                ))}
              </div>

              {/* Stickers */}
              {stickers.map((sticker, idx) => (
                <motion.div
                  key={idx}
                  initial={{ scale: 0, rotate: -20 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.3 + idx * 0.05 }}
                  className="absolute text-xl md:text-2xl"
                  style={{
                    top: `${15 + idx * 12}%`,
                    left: `${10 + (idx % 3) * 25}%`,
                  }}
                >
                  {sticker}
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>

          {/* Page number */}
          <div className="absolute bottom-2 right-4 text-xs text-secondary-foreground opacity-60 font-paragraph">
            Page {currentPage + 1} of {scrapbookPages.length}
          </div>
        </div>
      </motion.div>

      {/* Navigation buttons */}
      <div className="flex gap-4 items-center justify-center">
        <Button
          onClick={handlePrevPage}
          disabled={currentPage === 0 || isFlipping}
          variant="outline"
          size="sm"
          className="border-primary text-primary hover:bg-primary hover:text-primary-foreground disabled:opacity-50"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>

        <span className="text-sm font-paragraph text-secondary-foreground">
          {currentPage + 1} / {scrapbookPages.length}
        </span>

        <Button
          onClick={handleNextPage}
          disabled={currentPage === scrapbookPages.length - 1 || isFlipping}
          variant="outline"
          size="sm"
          className="border-primary text-primary hover:bg-primary hover:text-primary-foreground disabled:opacity-50"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
