import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.5 }}
      className="relative z-10 py-12 px-6"
    >
      <div className="max-w-[120rem] mx-auto">
        <div className="backdrop-blur-md bg-white/10 border border-white/30 rounded-3xl px-8 py-8 shadow-lg">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <motion.div
              animate={{
                scale: [1, 1.15, 1],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            >
              <Heart className="w-8 h-8 text-primary fill-current" />
            </motion.div>
            
            <p className="font-paragraph text-base text-foreground">
              Made with love, for someone special
            </p>
            
            <div className="flex items-center gap-2 text-sm text-foreground/70 font-paragraph">
              <span>Every moment matters</span>
              <Heart className="w-4 h-4 text-primary fill-current" />
              <span>{new Date().getFullYear()}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.footer>
  );
}
