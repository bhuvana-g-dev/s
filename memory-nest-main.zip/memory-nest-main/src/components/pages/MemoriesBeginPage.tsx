import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Scrapbook from '@/components/Scrapbook';
import RollerCoaster from '@/components/RollerCoaster';
import FloatingPetals from '@/components/FloatingPetals';

export default function MemoriesBeginPage() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(false);
  }, []);

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-accent-beige via-white to-accent-lavender overflow-hidden">
      {/* Floating decorations */}
      <FloatingPetals />

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="w-full h-screen flex items-center justify-center px-4 md:px-8"
      >
        <div className="w-full max-w-[120rem] h-full flex gap-4 md:gap-8 items-center justify-center">
          {/* Left side - Scrapbook (60%) */}
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full md:w-3/5 h-full flex items-center justify-center"
          >
            <Scrapbook />
          </motion.div>

          {/* Right side - Roller Coaster (40%) */}
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="w-full md:w-2/5 h-full flex items-center justify-center"
          >
            <RollerCoaster />
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
