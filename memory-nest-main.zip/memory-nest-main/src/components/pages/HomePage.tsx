// HPI 1.7-G
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { Heart, Sparkles, Star, Cloud, Sun, Moon, Gift, ArrowRight, PartyPopper, Music } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Image } from '@/components/ui/image';

// --- Constants & Data ---

const LOADING_MESSAGES = [
  "Loading a little surprise...",
  "Collecting beautiful memories...",
  "Wrapping today's happiness...",
  "Almost there, baby... ❤️",
  "Loading, Baby... ❤️"
];

const DAILY_MESSAGES = [
  "I hope today gives you at least one reason to smile. ❤️",
  "You make ordinary days special just by being in them.",
  "Thinking of you makes my day infinitely better.",
  "Sending you a warm hug through the screen.",
  "You are my favorite notification.",
  "Every day is a little brighter with you in it."
];

const JAR_MESSAGES = [
  "You make ordinary days special.",
  "Remember to smile today.",
  "Our story grows one day at a time.",
  "Another little memory waiting for us.",
  "I love the way your eyes light up.",
  "You are stronger and more amazing than you think.",
  "Just a reminder: you are deeply loved."
];

// --- Helper Functions ---

const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return { text: 'Good Morning', icon: Sun, color: 'text-amber-500' };
  if (hour < 18) return { text: 'Good Afternoon', icon: Cloud, color: 'text-sky-500' };
  if (hour < 22) return { text: 'Good Evening', icon: Star, color: 'text-indigo-400' };
  return { text: 'Good Night', icon: Moon, color: 'text-slate-600' };
};

const checkIsBirthday = () => {
  const today = new Date();
  return today.getMonth() === 6 && today.getDate() === 26; // July 26
};

const getDailyRandomItem = (array: string[]) => {
  // Simple seeded random based on current date so it stays the same for the day
  const today = new Date();
  const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
  const index = seed % array.length;
  return array[index];
};

// --- Components ---

const FloatingDecorations = () => {
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; scale: number; duration: number; delay: number; type: number }[]>([]);

  useEffect(() => {
    const newParticles = Array.from({ length: 25 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      scale: Math.random() * 0.6 + 0.4,
      duration: Math.random() * 15 + 15,
      delay: Math.random() * 5,
      type: Math.floor(Math.random() * 3)
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute text-primary/30"
          initial={{ x: `${p.x}vw`, y: '110vh', scale: p.scale, opacity: 0 }}
          animate={{ 
            y: '-10vh', 
            opacity: [0, 0.8, 0.8, 0],
            rotate: [0, 90, 180, 270, 360]
          }}
          transition={{ 
            duration: p.duration, 
            delay: p.delay, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        >
          {p.type === 0 ? <Heart size={24} fill="currentColor" /> : 
           p.type === 1 ? <Sparkles size={20} /> : 
           <Star size={16} fill="currentColor" />}
        </motion.div>
      ))}
    </div>
  );
};

const LoadingScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    if (msgIndex < LOADING_MESSAGES.length - 1) {
      const timer = setTimeout(() => {
        setMsgIndex(prev => prev + 1);
      }, 1200); // Change message every 1.2s
      return () => clearTimeout(timer);
    } else {
      const timer = setTimeout(() => {
        onComplete();
      }, 2000); // Hold the last message for 2s
      return () => clearTimeout(timer);
    }
  }, [msgIndex, onComplete]);

  return (
    <motion.div
      key="loading"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, filter: "blur(10px)" }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-accent-pink/30 via-background to-accent-lavender/30 overflow-hidden"
    >
      <FloatingDecorations />
      
      <motion.div
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className="relative z-10 flex flex-col items-center"
      >
        <div className="relative w-32 h-32 mb-8 flex items-center justify-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 rounded-full border-t-4 border-primary/50 border-r-4 border-r-transparent"
          />
          <Heart className="w-12 h-12 text-primary animate-pulse" fill="currentColor" />
        </div>

        <AnimatePresence mode="wait">
          <motion.p
            key={msgIndex}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.5 }}
            className="font-heading text-2xl md:text-3xl text-foreground/80 text-center px-6"
          >
            {LOADING_MESSAGES[msgIndex]}
          </motion.p>
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

const GreetingCard = () => {
  const isBirthday = checkIsBirthday();
  const greeting = getGreeting();
  const GreetingIcon = greeting.icon;
  const dailyMessage = getDailyRandomItem(DAILY_MESSAGES);
  
  const dateString = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, type: "spring", bounce: 0.3 }}
      className="relative w-full max-w-4xl mx-auto"
    >
      {/* Glass Card Container */}
      <div className="relative z-10 bg-white/40 backdrop-blur-xl border border-white/60 shadow-[0_8px_32px_0_rgba(255,182,193,0.2)] rounded-[32px] p-8 md:p-12 overflow-hidden">
        
        {/* Decorative corner blobs */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-secondary/30 rounded-full blur-3xl pointer-events-none" />
        
        {/* Content Grid with Image */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">

          {/* Left side - Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-center"
          >
            <div className="relative w-full max-w-xs">
              <Image src="https://static.wixstatic.com/media/6c5646_0f948d6fb6f142b3ad1fe365759e7536~mv2.png" alt="Decorative greeting image" className="w-full h-auto rounded-2xl shadow-lg" />
            </div>
          </motion.div>

          {/* Right side - Text Content */}
          <div className="space-y-6 relative z-10">
            {isBirthday ? (
              <>
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="flex gap-4 text-primary"
                >
                  <PartyPopper size={40} />
                  <Gift size={40} />
                  <PartyPopper size={40} className="scale-x-[-1]" />
                </motion.div>
                
                <h1 className="font-heading text-4xl md:text-5xl text-foreground font-bold tracking-tight">
                  Happy Birthday ❤️
                </h1>
                
                <p className="font-paragraph text-lg md:text-xl text-foreground/70 leading-relaxed">
                  Today is all about you. I hope your day is as beautiful, magical, and wonderful as you are.
                </p>
              </>
            ) : (
              <>
                <div className="inline-flex items-center px-4 py-1.5 rounded-full bg-white/50 border border-white/50 text-sm font-medium text-foreground/60">
                  {dateString}
                </div>
                
                <h1 className="font-heading text-4xl md:text-5xl text-foreground font-bold tracking-tight flex items-center gap-3">
                  {greeting.text} <GreetingIcon className={`w-8 h-8 ${greeting.color}`} />
                </h1>
                
                <div className="w-16 h-1 bg-primary/30 rounded-full my-6" />
                
                <p className="font-paragraph text-xl md:text-2xl text-foreground/80 leading-relaxed italic">
                  "{dailyMessage}"
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const MemoryJar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeMessage, setActiveMessage] = useState("");
  const isBirthday = checkIsBirthday();

  const handleOpenJar = () => {
    if (isOpen) return;
    const msg = isBirthday 
      ? "Happy Birthday! Here's to a million more beautiful memories together. 🎂❤️"
      : getDailyRandomItem(JAR_MESSAGES);
    setActiveMessage(msg);
    setIsOpen(true);
  };

  return (
    <div className="relative w-full max-w-6xl mx-auto py-20 flex flex-col items-center">
      <div className="text-center mb-12">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground font-bold mb-4">The Memory Jar</h2>
        <p className="font-paragraph text-foreground/60">Tap the jar to reveal today's little note.</p>
      </div>

      {/* Grid Layout: Jar on left, Images on right */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center w-full">
        {/* The Jar */}
        <motion.button
          onClick={handleOpenJar}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="relative w-64 h-80 cursor-pointer group outline-none mx-auto"
        >
          {/* Jar Lid */}
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-48 h-12 bg-[#D2B48C] rounded-t-2xl border-b-4 border-[#C19A6B] z-20 shadow-md flex items-center justify-center">
             <div className="w-full h-2 bg-white/20 absolute top-2 rounded-full px-4" />
          </div>
          
          {/* Jar Body (Glass) */}
          <div className="absolute inset-0 bg-white/20 backdrop-blur-md border-4 border-white/40 rounded-b-[40px] rounded-t-xl shadow-[inset_0_0_40px_rgba(255,255,255,0.5),0_20px_40px_rgba(0,0,0,0.05)] overflow-hidden z-10">
            {/* Highlights */}
            <div className="absolute top-0 left-4 w-8 h-full bg-gradient-to-r from-white/40 to-transparent skew-x-12" />
            
            {/* Folded Papers inside */}
            <div className="absolute bottom-4 left-0 w-full h-1/2 flex flex-wrap justify-center items-end gap-2 p-4 opacity-80">
              {Array.from({ length: 12 }).map((_, i) => (
                <div 
                  key={i} 
                  className="w-12 h-8 bg-white/90 rounded-sm shadow-sm border border-gray-100"
                  style={{ 
                    transform: `rotate(${Math.random() * 60 - 30}deg) translate(${Math.random() * 20 - 10}px, ${Math.random() * 10}px)` 
                  }}
                />
              ))}
            </div>
          </div>

          {/* Glow effect on hover */}
          <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </motion.button>

        {/* Images on the right */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col gap-6"
        >
          <div className="relative w-full h-48 rounded-2xl overflow-hidden shadow-lg">
            <Image src="https://static.wixstatic.com/media/6c5646_0f948d6fb6f142b3ad1fe365759e7536~mv2.png" alt="Memory jar decoration" className="w-full h-full object-cover" />
          </div>
        </motion.div>
      </div>

      {/* The Opened Note Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
            onClick={() => setIsOpen(false)}
          >
            <motion.div
              initial={{ scale: 0, y: 100, rotate: -10 }}
              animate={{ scale: 1, y: 0, rotate: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 50 }}
              transition={{ type: "spring", damping: 15, stiffness: 100 }}
              className="relative bg-[#FFFDF5] w-full max-w-md aspect-square rounded-sm shadow-2xl p-8 flex flex-col items-center justify-center text-center cursor-default"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Paper texture/creases */}
              <div className="absolute inset-0 opacity-10 pointer-events-none border-x border-black/20" style={{ backgroundImage: 'linear-gradient(90deg, transparent 49%, rgba(0,0,0,0.1) 50%, transparent 51%)' }} />
              <div className="absolute inset-0 opacity-10 pointer-events-none border-y border-black/20" style={{ backgroundImage: 'linear-gradient(0deg, transparent 49%, rgba(0,0,0,0.1) 50%, transparent 51%)' }} />
              
              <Heart className="w-8 h-8 text-primary mb-6 opacity-50" fill="currentColor" />
              <p className="font-heading text-2xl md:text-3xl text-foreground/80 leading-relaxed">
                {activeMessage}
              </p>
              
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute bottom-6 text-sm font-paragraph text-foreground/40 hover:text-foreground/60 transition-colors"
              >
                Tap anywhere to close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const BikeTransition = () => {
  const navigate = useNavigate();
  const [isRiding, setIsRiding] = useState(false);

  const handleRide = () => {
    if (isRiding) return;
    setIsRiding(true);
    
    // Ride for 2s, then navigate to memories page
    setTimeout(() => {
      navigate('/memories-begin');
    }, 2000);
  };

  return (
    <div className="relative w-full min-h-[60vh] flex flex-col items-center justify-end pb-20 overflow-hidden">
      
      {/* Scenery Background that moves when riding */}
      <motion.div 
        className="absolute bottom-20 left-0 w-[200%] h-32 flex items-end opacity-30 pointer-events-none"
        animate={isRiding ? { x: "-50%" } : { x: "0%" }}
        transition={{ duration: 4, ease: "linear" }}
      >
        {/* Simple CSS trees/hills */}
        <div className="w-64 h-32 bg-secondary rounded-t-full mx-10" />
        <div className="w-40 h-20 bg-primary/20 rounded-t-full mx-4" />
        <div className="w-80 h-40 bg-accent-beige rounded-t-full mx-12" />
        <div className="w-64 h-32 bg-secondary rounded-t-full mx-10" />
        <div className="w-40 h-20 bg-primary/20 rounded-t-full mx-4" />
      </motion.div>

      {/* The Ground Line */}
      <div className="absolute bottom-20 w-full h-[2px] bg-foreground/10" />

      {/* The Bike & Prompt */}
      <div className="relative z-10 flex flex-col items-center">
        <AnimatePresence>
          {!isRiding && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-8 text-center"
            >
              <p className="font-paragraph text-foreground/60 mb-2">Ready for the next chapter?</p>
              <div className="flex items-center justify-center gap-2 text-primary animate-bounce">
                <ArrowRight size={20} />
                <span className="font-heading font-medium">Tap the bike</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={handleRide}
          animate={isRiding ? { x: "150vw" } : { x: 0, y: [0, -5, 0] }}
          transition={
            isRiding 
              ? { duration: 3, ease: "easeInOut" } 
              : { duration: 2, repeat: Infinity, ease: "easeInOut" }
          }
          className="relative outline-none group"
        >
          {/* Using a placeholder image for the cute illustration as requested, styled to look like a sticker */}
          <div className="relative w-48 h-48 bg-white rounded-full shadow-lg border-4 border-white overflow-hidden group-hover:scale-105 transition-transform duration-300">
             <Image src="https://static.wixstatic.com/media/6c5646_0f948d6fb6f142b3ad1fe365759e7536~mv2.png" alt="Cute bike illustration" className="w-full h-full object-cover" />
             {/* Overlay tint to match theme */}
             <div className="absolute inset-0 bg-primary/10 mix-blend-multiply" />
          </div>
          
          {/* Motion lines when riding */}
          {isRiding && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute top-1/2 -left-12 flex flex-col gap-2"
            >
              <div className="w-8 h-1 bg-foreground/20 rounded-full" />
              <div className="w-12 h-1 bg-foreground/20 rounded-full -ml-4" />
              <div className="w-6 h-1 bg-foreground/20 rounded-full" />
            </motion.div>
          )}
        </motion.button>
      </div>

{/* ... keep existing code (no overlay needed) */}
    </div>
  );
};

// --- Main Page Component ---

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  // Subtle background parallax
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  return (
    <AnimatePresence mode="wait">
      {isLoading ? (
        <LoadingScreen key="loading" onComplete={() => setIsLoading(false)} />
      ) : (
        <motion.div
          key="home"
          ref={containerRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="min-h-screen bg-background relative overflow-clip selection:bg-primary/30"
        >
          {/* Animated Background Gradient */}
          <motion.div 
            style={{ y: bgY }}
            className="absolute inset-0 -top-[20%] h-[140%] w-full bg-[radial-gradient(circle_at_50%_0%,_var(--tw-gradient-stops))] from-accent-pink/20 via-background to-accent-lavender/20 pointer-events-none z-0"
          />
          
          <FloatingDecorations />
          
          {/* Header is preserved as requested, though it might be empty in this specific design context */}
          <div className="relative z-50">
            <Header />
          </div>
          
          <main className="relative z-10 flex flex-col gap-20 md:gap-32 pb-20">
            
            {/* Hero Section */}
            <section id="hero" className="min-h-[80vh] flex items-center justify-center px-4 pt-32">
              <div className="w-full max-w-[120rem] mx-auto">
                <GreetingCard />
              </div>
            </section>

            {/* Memory Jar Section */}
            <section id="memory-jar" className="min-h-[60vh] flex items-center justify-center px-4">
              <div className="w-full max-w-[120rem] mx-auto">
                <MemoryJar />
              </div>
            </section>

            {/* Bike Transition Section */}
            <section id="transition" className="min-h-[60vh] flex items-end justify-center px-4">
              <div className="w-full max-w-[120rem] mx-auto">
                <BikeTransition />
              </div>
            </section>

          </main>

          <div className="relative z-50">
            <Footer />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}