import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import FloatingPetals from '@/components/FloatingPetals';

export default function OurJourneyPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-accent-beige via-white to-accent-lavender overflow-hidden flex items-center justify-center">
      {/* Floating decorations */}
      <FloatingPetals />

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-2xl px-4 md:px-8 text-center"
      >
        {/* Decorative elements */}
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 4, repeat: Infinity }}
          className="text-6xl md:text-8xl mb-8"
        >
          🎢
        </motion.div>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-4xl md:text-6xl font-heading text-primary mb-6"
        >
          Our Journey
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-xl md:text-2xl font-paragraph text-secondary-foreground mb-8"
        >
          Every picture tells a story. Every story reminds me of you.
        </motion.p>

        {/* Coming soon message */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-gradient-to-r from-primary/10 to-accent-lavender/10 rounded-2xl p-8 md:p-12 mb-8 border-2 border-primary/20"
        >
          <p className="text-lg font-paragraph text-secondary-foreground mb-4">
            ✨ Memory Gallery Coming Soon ❤️
          </p>
          <p className="text-sm md:text-base font-paragraph text-secondary-foreground opacity-75">
            This page will soon contain:
          </p>
          <ul className="text-sm md:text-base font-paragraph text-secondary-foreground opacity-75 mt-4 space-y-2">
            <li>📸 Our photos together</li>
            <li>🎥 Videos</li>
            <li>🎙️ Voice recordings</li>
            <li>💝 Special memories</li>
            <li>📅 Timeline</li>
          </ul>
        </motion.div>

        {/* Decorative elements */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="inline-block text-4xl mb-8"
        >
          💕
        </motion.div>

        {/* Back button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="flex gap-4 justify-center"
        >
          <Button
            onClick={() => navigate('/memories-begin')}
            variant="outline"
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            ← Back to Scrapbook
          </Button>
          <Button
            onClick={() => navigate('/')}
            className="bg-gradient-to-r from-primary to-accent-pink text-primary-foreground font-heading"
          >
            Home 🏠
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
