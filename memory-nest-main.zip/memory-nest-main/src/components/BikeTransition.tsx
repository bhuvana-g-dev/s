import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Sparkles } from 'lucide-react';

export default function BikeTransition() {
  const [isRiding, setIsRiding] = useState(false);
  const [showNextPage, setShowNextPage] = useState(false);

  const handleBikeClick = () => {
    setIsRiding(true);
    setTimeout(() => {
      setShowNextPage(true);
    }, 2000);
  };

  return (
    <div className="relative w-full min-h-screen flex items-center justify-center overflow-hidden">
      <AnimatePresence mode="wait">
        {!showNextPage ? (
          <motion.div
            key="bike-section"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full max-w-4xl mx-auto text-center px-4"
          >
            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: -30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-12"
            >
              <h2 className="font-heading text-4xl md:text-5xl text-foreground font-bold mb-4">
                Ready for More?
              </h2>
              <p className="font-paragraph text-lg text-foreground/70">
                Click the bike to continue our journey
              </p>
            </motion.div>

            {/* Bike Illustration Container */}
            <motion.div
              className="relative"
              animate={isRiding ? {
                x: [0, window.innerWidth + 200]
              } : {}}
              transition={{
                duration: 2,
                ease: 'easeInOut'
              }}
            >
              <motion.button
                onClick={handleBikeClick}
                disabled={isRiding}
                className="relative mx-auto block cursor-pointer disabled:cursor-default focus:outline-none"
                whileHover={!isRiding ? { scale: 1.05 } : {}}
                whileTap={!isRiding ? { scale: 0.95 } : {}}
                animate={!isRiding ? {
                  y: [0, -10, 0]
                } : {}}
                transition={{
                  duration: 2,
                  repeat: isRiding ? 0 : Infinity,
                  ease: 'easeInOut'
                }}
              >
                {/* Glass Card with Bike Illustration */}
                <div className="backdrop-blur-lg bg-white/20 border border-white/40 rounded-3xl p-12 shadow-2xl">
                  {/* Simple Bike Illustration using shapes */}
                  <div className="relative w-64 h-40 mx-auto">
                    {/* Bike Frame */}
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      {/* Back Wheel */}
                      <motion.div
                        animate={isRiding ? {
                          rotate: [0, 360]
                        } : {}}
                        transition={{
                          duration: 0.5,
                          repeat: isRiding ? Infinity : 0,
                          ease: 'linear'
                        }}
                        className="absolute -left-16 top-8 w-16 h-16 rounded-full border-4 border-primary bg-white/20"
                      >
                        <div className="absolute top-1/2 left-1/2 w-1 h-full bg-primary transform -translate-x-1/2 -translate-y-1/2" />
                        <div className="absolute top-1/2 left-1/2 w-full h-1 bg-primary transform -translate-x-1/2 -translate-y-1/2" />
                      </motion.div>

                      {/* Front Wheel */}
                      <motion.div
                        animate={isRiding ? {
                          rotate: [0, 360]
                        } : {}}
                        transition={{
                          duration: 0.5,
                          repeat: isRiding ? Infinity : 0,
                          ease: 'linear'
                        }}
                        className="absolute left-16 top-8 w-16 h-16 rounded-full border-4 border-primary bg-white/20"
                      >
                        <div className="absolute top-1/2 left-1/2 w-1 h-full bg-primary transform -translate-x-1/2 -translate-y-1/2" />
                        <div className="absolute top-1/2 left-1/2 w-full h-1 bg-primary transform -translate-x-1/2 -translate-y-1/2" />
                      </motion.div>

                      {/* Frame Lines */}
                      <div className="absolute left-0 top-10 w-32 h-1 bg-primary transform rotate-12" />
                      <div className="absolute left-8 top-4 w-20 h-1 bg-primary transform -rotate-45" />
                      <div className="absolute left-16 top-10 w-16 h-1 bg-primary transform rotate-45" />

                      {/* Seat */}
                      <div className="absolute -left-4 -top-2 w-12 h-4 bg-primary rounded-full" />

                      {/* Handlebar */}
                      <div className="absolute left-20 -top-4 w-8 h-2 bg-primary rounded-full" />

                      {/* Two Girls (simplified) */}
                      <div className="absolute left-0 -top-8">
                        {/* Girl 1 */}
                        <div className="absolute left-0">
                          <div className="w-8 h-8 rounded-full bg-accent-pink border-2 border-primary" />
                          <div className="w-6 h-10 bg-accent-lavender rounded-lg mt-1 ml-1" />
                        </div>
                        {/* Girl 2 */}
                        <div className="absolute left-12">
                          <div className="w-8 h-8 rounded-full bg-accent-lavender border-2 border-primary" />
                          <div className="w-6 h-10 bg-accent-pink rounded-lg mt-1 ml-1" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Hearts floating around */}
                  {!isRiding && (
                    <>
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={`bike-heart-${i}`}
                          className="absolute text-primary"
                          style={{
                            left: `${30 + i * 20}%`,
                            top: `${20 + i * 15}%`
                          }}
                          animate={{
                            y: [0, -20, 0],
                            opacity: [0.5, 1, 0.5]
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            delay: i * 0.4,
                            ease: 'easeInOut'
                          }}
                        >
                          <Heart className="w-5 h-5 fill-current" />
                        </motion.div>
                      ))}
                    </>
                  )}
                </div>

                {/* Click hint */}
                {!isRiding && (
                  <motion.div
                    animate={{
                      opacity: [0.5, 1, 0.5]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut'
                    }}
                    className="mt-6 font-paragraph text-foreground/70"
                  >
                    Click to ride ✨
                  </motion.div>
                )}
              </motion.button>

              {/* Trail sparkles when riding */}
              {isRiding && (
                <>
                  {[...Array(10)].map((_, i) => (
                    <motion.div
                      key={`trail-${i}`}
                      className="absolute top-1/2 text-primary"
                      initial={{ 
                        x: 0,
                        opacity: 1,
                        scale: 1
                      }}
                      animate={{
                        x: -100,
                        opacity: 0,
                        scale: 0
                      }}
                      transition={{
                        duration: 1,
                        delay: i * 0.1,
                        ease: 'easeOut'
                      }}
                    >
                      <Sparkles className="w-6 h-6" />
                    </motion.div>
                  ))}
                </>
              )}
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            key="next-page"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center px-4"
          >
            <motion.div
              animate={{
                scale: [1, 1.1, 1]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            >
              <Heart className="w-20 h-20 text-primary fill-current mx-auto mb-8" />
            </motion.div>
            
            <h2 className="font-heading text-4xl md:text-5xl text-foreground font-bold mb-6">
              More memories are coming soon...
            </h2>
            
            <p className="font-paragraph text-xl text-foreground/70">
              ❤️
            </p>

            {/* Floating sparkles */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={`end-sparkle-${i}`}
                className="absolute text-primary"
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: `${20 + Math.random() * 60}%`
                }}
                animate={{
                  y: [0, -30, 0],
                  opacity: [0.3, 1, 0.3],
                  scale: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.5,
                  ease: 'easeInOut'
                }}
              >
                <Sparkles className="w-6 h-6" />
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
