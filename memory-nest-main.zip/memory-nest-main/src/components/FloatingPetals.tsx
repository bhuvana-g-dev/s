import { motion } from 'framer-motion';

export default function FloatingPetals() {
  const petals = Array.from({ length: 12 }, (_, i) => i);
  const sparkles = Array.from({ length: 8 }, (_, i) => i);

  return (
    <>
      {/* Floating petals */}
      {petals.map((i) => (
        <motion.div
          key={`petal-${i}`}
          className="fixed pointer-events-none"
          initial={{
            x: Math.random() * window.innerWidth,
            y: -20,
            opacity: 0,
          }}
          animate={{
            y: window.innerHeight + 20,
            opacity: [0, 1, 1, 0],
            x: Math.random() * window.innerWidth,
            rotate: 360,
          }}
          transition={{
            duration: 8 + Math.random() * 4,
            repeat: Infinity,
            delay: i * 0.5,
            ease: 'linear',
          }}
        >
          <div className="text-2xl">🌸</div>
        </motion.div>
      ))}

      {/* Floating sparkles */}
      {sparkles.map((i) => (
        <motion.div
          key={`sparkle-${i}`}
          className="fixed pointer-events-none"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0,
            scale: 0,
          }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 2 + Math.random() * 2,
            repeat: Infinity,
            delay: i * 0.8,
          }}
        >
          <div className="text-lg">✨</div>
        </motion.div>
      ))}
    </>
  );
}
