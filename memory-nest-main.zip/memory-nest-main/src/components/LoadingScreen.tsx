import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heart, Sparkles } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { LoadingScreenMessages } from '@/entities';

export default function LoadingScreen() {
  const [currentMessage, setCurrentMessage] = useState('Loading a little surprise...');
  const [messages, setMessages] = useState<LoadingScreenMessages[]>([]);

  useEffect(() => {
    loadMessages();
  }, []);

  const loadMessages = async () => {
    try {
      const result = await BaseCrudService.getAll<LoadingScreenMessages>('loadingscreenmessages');
      const activeMessages = result.items
        .filter(msg => msg.isActive)
        .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
      
      if (activeMessages.length > 0) {
        setMessages(activeMessages);
        cycleMessages(activeMessages);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const cycleMessages = (msgs: LoadingScreenMessages[]) => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < msgs.length) {
        setCurrentMessage(msgs[index].messageText || 'Loading...');
        index++;
      } else {
        clearInterval(interval);
      }
    }, 800);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-background via-accent-beige to-accent-pink"
    >
      {/* Floating Hearts */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`heart-${i}`}
          className="absolute text-primary opacity-30"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: window.innerHeight + 50,
            scale: 0.5 + Math.random() * 0.5
          }}
          animate={{
            y: -100,
            x: Math.random() * window.innerWidth,
          }}
          transition={{
            duration: 8 + Math.random() * 4,
            repeat: Infinity,
            delay: i * 0.5,
            ease: 'linear'
          }}
        >
          <Heart className="w-6 h-6 fill-current" />
        </motion.div>
      ))}

      {/* Floating Sparkles */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={`sparkle-${i}`}
          className="absolute text-accent-lavender opacity-40"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            scale: 0.3 + Math.random() * 0.7,
            rotate: 0
          }}
          animate={{
            y: [null, Math.random() * window.innerHeight],
            x: [null, Math.random() * window.innerWidth],
            rotate: 360,
            scale: [null, 0.3 + Math.random() * 0.7]
          }}
          transition={{
            duration: 6 + Math.random() * 4,
            repeat: Infinity,
            delay: i * 0.3,
            ease: 'easeInOut'
          }}
        >
          <Sparkles className="w-5 h-5" />
        </motion.div>
      ))}

      {/* Central Content */}
      <div className="relative z-10 text-center px-6">
        {/* Breathing Animation Container */}
        <motion.div
          animate={{
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="mb-8"
        >
          <motion.div
            className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-primary to-accent-pink flex items-center justify-center shadow-lg"
            animate={{
              boxShadow: [
                '0 0 20px rgba(255, 182, 193, 0.3)',
                '0 0 40px rgba(255, 182, 193, 0.6)',
                '0 0 20px rgba(255, 182, 193, 0.3)',
              ]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          >
            <Heart className="w-12 h-12 text-primary-foreground fill-current" />
          </motion.div>
        </motion.div>

        {/* Loading Message */}
        <motion.div
          key={currentMessage}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.5 }}
          className="font-heading text-2xl md:text-3xl text-foreground"
        >
          {currentMessage}
        </motion.div>

        {/* Loading Dots */}
        <div className="flex justify-center gap-2 mt-6">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-3 h-3 rounded-full bg-primary"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: i * 0.2,
                ease: 'easeInOut'
              }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
