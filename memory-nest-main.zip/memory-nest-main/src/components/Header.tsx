import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function Header() {
  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.2 }}
      className="fixed top-0 left-0 right-0 z-40 px-6 py-6"
    >
      <div className="max-w-[120rem] mx-auto">
        <div className="flex items-center justify-between backdrop-blur-md bg-white/10 border border-white/30 rounded-3xl px-8 py-4 shadow-lg">
          <motion.div
            className="flex items-center gap-3"
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <Heart className="w-6 h-6 text-primary fill-current" />
            <span className="font-heading text-xl md:text-2xl text-foreground font-semibold">
              Our Little World
            </span>
          </motion.div>
          
          <motion.div
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          >
            <Heart className="w-5 h-5 text-primary fill-current" />
          </motion.div>
        </div>
      </div>
    </motion.header>
  );
}
